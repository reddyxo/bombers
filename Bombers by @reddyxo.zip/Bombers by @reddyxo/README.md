There are two bombers in the folder which works perfectly

For Gmail Server you Have to Enable "less Secure app" From here:->
https://myaccount.google.com/lesssecureapps

Open Terminal in the folder by right clicking and clicking on open terminal here

type

chmod +x EmBomber.py
chmod +x EmBomber-updated.py
chmod +x BomMaiL.py

updated works with python3 use direct./EmBomber-updated.py

for remaining scripts use

sudo python2 BomMaiL.py

and
sudo python2 EmBomber.py